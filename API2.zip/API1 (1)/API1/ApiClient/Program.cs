﻿using System.Net.Http;
using System;
using System.Threading.Tasks;

class Program
{
    static async Task Main(string[] args)
    {
        var client = new HttpClient();
        client.BaseAddress = new Uri("https://localhost:7009/");

        var data = new
        {
            A = 10,
            B = 2
        };

        try
        {
            var response = await client.PostAsJsonAsync("api/calculator/calculate", data);
            var result = await response.Content.ReadAsStringAsync();

            Console.WriteLine($"Результат умножения: {result}");
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Ошибка: {ex.Message}");
        }
    }
        private readonly HttpClient _client = new HttpClient
        {
            BaseAddress = new Uri("https://localhost:5001/")

        };

}
