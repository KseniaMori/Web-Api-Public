﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace Web_API.Models  //https://localhost:7009/ 
{
    [ApiController]
    [Route("api/[controller]")]
    public class CalculatorController : ControllerBase
    {
        [HttpPost("calculate")]
        public double Calculate(CalcRequest request)
        {
            // Умножение (вариант 2)
            return request.A * request.B;
        }
    }
}
