﻿namespace Web_API.Models
{
    public class Calculation
    {

        public int Id { get; set; }
        public double A { get; set; }
        public double B { get; set; }
        public double Result { get; set; }
        public DateTime CreatedAt { get; set; }
        [HttpGet]
        public List<Calculation> GetAll()
        {
            return _context.Calculations.ToList();
        }
    }
}
