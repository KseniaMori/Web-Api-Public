﻿namespace Web_API.Models
{
    using Microsoft.EntityFrameworkCore;
    public class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> options)
        : base(options) { }
        public DbSet<Calculation> Calculations { get; set; }
    }
    public class CalculatorController : ControllerBase
    {
        private readonly AppDbContext _context;
        public CalculatorController(AppDbContext context)
        {
            _context = context;
        }
    }
    var history = await _client.GetFromJsonAsync<List<Calculation>>(
"api/calculator");
   

}
