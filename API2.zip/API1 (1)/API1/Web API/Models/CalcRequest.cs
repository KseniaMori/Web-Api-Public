﻿namespace Web_API.Models
{
    public class CalcRequest
    {
        public double A { get; set; }
        public double B { get; set; }
        var request = new CalcRequest
        {
            A = double.Parse(TextBoxA.Text),
            B = double.Parse(TextBoxB.Text)
        };
        var response = await _client.PostAsJsonAsync(
        "api/calculator/calculate", request);
        var result = await response.Content.ReadAsStringAsync();
      
    }

}
