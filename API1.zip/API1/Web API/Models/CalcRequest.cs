﻿namespace Web_API.Models
{
    public class CalcRequest
    {
        public double A { get; set; }
        public double B { get; set; }
    }
}
